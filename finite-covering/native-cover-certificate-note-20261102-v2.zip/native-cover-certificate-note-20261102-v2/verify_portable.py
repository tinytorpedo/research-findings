"""Independent direct integer audit; no imports from generator or archive scripts."""
import collections,hashlib,json,math,time,sys
from pathlib import Path
P=Path(__file__).resolve().parent
S=P/'archive'
def load(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def prime(n): return n>=2 and not any(n%d==0 for d in range(2,math.isqrt(n)+1))
start=time.perf_counter();d=load(P/'AGGREGATES.json')
assert sha(P/'AGGREGATES.json')==load(P/'AGGREGATES_LOCK.json')['sha256']
assert prime(37) and prime(41) and not any(prime(n) for n in range(38,41))
assert 11**3<=1680<12**3
base=[m for m in range(1370,1680) if m%6==0]
small=[r for r in range(2,12) if prime(r)]
active=[r for r in range(12,38) if prime(r)]
cohort=[m for m in base if all((m-1)%r and (m+1)%r for r in small)]
assert len(base)==d['raw_population']==51 and cohort==d['cohort'] and active==d['active_primes']
raw=collections.Counter((r,s) for m in base for r in active for s in (-1,1) if (m-s)%r==0)
cap=collections.Counter((r,s) for m in cohort for r in active for s in (-1,1) if (m-s)%r==0)
pairs=collections.Counter((r,s) for m in cohort for r in active for s in active if r!=s and (m-1)%r==0 and (m+1)%s==0)
for a in d['capacities']:
 key=(a['prime'],a['residue']); assert a['raw']==raw[key] and a['conditioned']==cap[key]
for a in d['all_oriented_overlaps']: assert a['count']==pairs[a['left'],a['right']]
R=len(cohort);H=sum(cap.values());J=sum(pairs.values()); assert (R,H,J)==(15,9,1)
for level,(rows,bound) in enumerate(zip(d['relaxed_witnesses'],[15,15,9,8]),1):
 usage=collections.Counter(); overlaps=collections.Counter()
 assert len(rows)==R
 for row in rows:
  assert len(row)<=2
  assert all(r in active and s in (-1,1) for r,s in row)
  if len(row)==2:
   assert len({r for r,s in row})==2 and {s for r,s in row}=={-1,1}
   overlaps[next(r for r,s in row if s==1),next(r for r,s in row if s==-1)]+=1
  usage.update(map(tuple,row))
 if level>=2: assert all(v<=raw[k] for k,v in usage.items())
 if level>=3: assert all(v<=cap[k] for k,v in usage.items())
 if level>=4: assert all(overlaps[k]>=v for k,v in pairs.items())
 assert sum(bool(row) for row in rows)==bound==d['coverage_maxima'][level-1]
actual=[]; twins=[]
for m in cohort:
 le=[r for r in active if (m-1)%r==0];ri=[r for r in active if (m+1)%r==0]
 assert len(le)<=1 and len(ri)<=1 and not set(le)&set(ri)
 assert (not le)==prime(m-1) and (not ri)==prime(m+1)
 if not le and not ri: twins.append(m)
 actual.append({'center':m,'left_endpoint':m-1,'right_endpoint':m+1,'left_clocks':le,'right_clocks':ri})
assert actual==load(P/'POST_LOCK_ROWS.json')
assert twins==[1428,1452,1482,1488,1608,1620,1668] and len(twins)==R-H+J
arch=load(S/'outputs/cover_null_v1/RESULTS.json')
assert arch['cohort']==cohort and (arch['R'],arch['H'],arch['J'])==(R,H,J)
assert [a['exact_optimum'] for a in arch['levels']]==d['coverage_maxima']
frozen=load(P/'PORTABLE_FREEZE.json')
for rel,h in frozen['original_inputs'].items(): assert sha(S/rel)==h
# Saved-record consistency audit ONLY, not re-verification of every CRT constraint.
many=load(S/'outputs/cover_level3_search_v2/VERIFICATION.json')
summary=load(S/'outputs/cover_level3_search_v2/COMBINED_SUMMARY.json')
earlier=load(S/'outputs/cover_level3_search_v1/VERIFICATION.json')
assert earlier['all_checks_pass'] and many['all_checks_pass']
assert len(earlier['bands'])==143 and len(many['bands'])==501
bs=earlier['bands']+many['bands'];assert len(bs)==644
assert len({(a['p'],a['q']) for a in bs})==644
assert all(a['lower_bound']==a['R']-a['C3'] and a['C3']==a['H'] and 0<a['lower_bound']<=a['T'] for a in bs)
assert sum(a['R'] for a in bs)==summary['R']==362803
assert sum(a['lower_bound'] for a in bs)==summary['guaranteed_twins']==72196
assert sum(a['T'] for a in bs)==summary['actual_twins']==130459
assert [bs[0]['p'],bs[0]['q']]==summary['first']==[101,103]
assert [bs[-1]['p'],bs[-1]['q']]==summary['last']==[4999,5003]
out={'status':'PASS','fixture':'retrospective known 37-41 band','R':R,'raw_capacity_sum':sum(raw.values()),'H':H,'J':J,
 'exact_relaxed_coverage':[15,15,9,8],'twin_lower_bounds':[0,0,6,7],'twin_centers':twins,'original_input_hashes_unchanged':True,
 'direct_named_row_audit':True,'all_14_capacities_and_42_oriented_overlaps_match':True,'all_four_witnesses_attain_proved_bounds':True,
 'controls':{'unconditioned_sum':sum(raw.values()),'without_overlap_guarantee':R-H,'with_overlap_guarantee':R-H+J,'same_clock_pair_rejected_by_alphabet':True},
 'broader_archive_consistency_only':{'bands':len(bs),'R':summary['R'],'guaranteed':summary['guaranteed_twins'],'actual':summary['actual_twins'],'new_arithmetic_rerun':False},
 'method_independence':'fresh direct trial division and enumeration; no generator import; same Python integer runtime; not third-party review',
 'wall_seconds':time.perf_counter()-start,'command':'python -B verify_portable.py','python':sys.version}
target=P/'VERIFICATION.json'
if target.exists():raise FileExistsError(target)
target.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(out,indent=2))
