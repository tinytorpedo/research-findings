# Aggregate clock-cover certificates in a prime-square band

## Abstract

We give a self-contained, retrospectively reproduced finite example of an information-restricted covering hierarchy. In the consecutive prime-square band for 37 and 41, a cube-root roughness filter retains fifteen candidate twin centers. A relaxed covering problem using only an admissible row alphabet or unconditioned capacities permits all fifteen rows to be covered. Cutoff-conditioned aggregate capacities reduce the maximum to nine; forced opposite-clock overlap reduces it to eight. Explicit feasible assignments attain each bound. Consequently these aggregate data certify six and then seven twin centers, respectively. Direct integer verification finds exactly seven. The fourth level is an exact degree-two inclusion-exclusion count, not a new uniform sieve or Jacobsthal theorem. The contribution here is an auditable example and reproducibility packet, not a claimed novel number-theoretic bound or computational advantage.

## 1. Arithmetic population and admissible information

Let p<q be consecutive primes, p>=5, X=q^2-1, and y=floor(X^(1/3)). Candidate centers are the multiples of six m strictly between p^2 and q^2-1, equivalently m=p^2+5,...,q^2-7 in steps of six. Retain only centers for which neither m-1 nor m+1 is divisible by any prime <=y. Denote this named cohort by C and its size by R. Active clocks are the primes y<r<=p. An incidence (r,L) means r divides m-1, equivalently m=1 mod r; (r,R) means r divides m+1, equivalently m=-1 mod r.

For a retained endpoint n, every prime factor is >X^(1/3); hence n has at most two prime factors with multiplicity. No prime square lies strictly between consecutive prime squares. A composite endpoint is therefore n=ab with distinct primes a<=p<b. Thus each endpoint has exactly one active incidence if composite and none if prime. The same active prime cannot strike both endpoints, since their difference is two. Each row consequently has the alphabet: empty, one left incidence, one right incidence, or two opposite incidences with distinct clocks. An empty row is exactly a twin center. These conclusions use standard trial division and unique factorization.

The generator may construct C using only small-prime roughness. It may compute complete-interval CRT counts, including small-prime inclusion-exclusion, but may not inspect active incidences or primality at individual named rows before the aggregate result is locked. This is an information contract of the computation; the historical fixture and outcome were already known. It is not a blind test, and aggregate CRT counting itself is sieve information.

## 2. General finite covering lemma

Consider R labeled rows and an arbitrary finite clock set. Each row has the alphabet above. Let I be the total number of incidences, P the number of double rows, and V the number of nonempty rows. Then

    V = I-P,                  empty rows = R-I+P.

Indeed a singleton contributes one to I and zero to P, a double contributes two to I and one to P, and an empty row contributes neither. If each clock-side usage is <=a_(r,s), write H=sum a_(r,s). If the number of each oriented double (r,L),(t,R) is >=b_(r,t), r!=t, write J=sum b_(r,t). Each double belongs to exactly one such oriented type. Therefore

    V <= min(R,H-J),           empty rows >= max(0,R-H+J).

Other upper bounds may be intersected with this one. No independence, random signs, or spatial assignment of the counts is needed. This lemma is elementary degree-two inclusion-exclusion. It must not be applied where two active clocks may strike the same endpoint or where higher-degree rows occur.

## 3. Exact aggregate counts without active named-row queries

For congruences m=a mod d on an inclusive interval [lo,hi], the progression count is

    floor((hi-a)/d) - floor((lo-1-a)/d).

All moduli below are distinct primes together with six, so CRT supplies one residue a modulo their product. Write N(F) for this count with m=0 mod6 and a list F of additional forced congruences. With small primes S={5,7,11}, the cutoff-conditioned count is

    N_rough(F) = sum_(epsilon in {0,-1,1}^S)
                    (-1)^(number of nonzero epsilon)
                    N(F union {m=epsilon_l mod l : epsilon_l !=0}).

This expands the exact product over l of (1-1_(m=1 mod l)-1_(m=-1 mod l)). On multiples of six, primes two and three cannot divide the endpoints. There are 27 CRT terms per forced pattern. Raw capacities are N({m=s mod r}); conditioned capacities are N_rough({m=s mod r}). Oriented pair counts are N_rough({m=1 mod r,m=-1 mod t}), r!=t. Thus H and J can be computed by aggregate progression counts without querying active divisibility at named survivor rows.

For p=37,q=41: X=1680,y=11, lo=1374,hi=1674; there are 51 raw centers, R=15 retained rows, and active clocks 13,17,19,23,29,31,37. All fourteen raw capacities sum to31; their conditioned analogues sum to H=9. The only positive oriented overlap is (left17,right13), with count1, at center1650, so J=1. TABLES.md gives every capacity, retained row, and a mathematical description of attaining assignments. Machine-readable AGGREGATES.json retains all42 oriented pair counts, including zero counts.

## 4. Four cumulative relaxed optimization problems

Every problem assigns alphabet states to the same fifteen named rows, but does NOT require an assigned incidence to be arithmetically valid at that row. Such witnesses prove sharpness of a relaxation, not realizability at the named addresses.

* C1: only the row alphabet. Maximum coverage15, attained by fifteen identical singleton left13 states.
* C2: C1 plus clock-side upper capacities from raw progression counts. Maximum15: its upper bound is min(15,31), and fifteen distinct capacity tokens can be placed as singletons on different rows.
* C3: C2 plus cutoff-conditioned clock-side upper capacities. Maximum9: I<=9 implies V<=9. Place each of the nine conditioned capacity tokens on a separate row and leave six rows empty. This obeys all raw capacities as well.
* C4: C3 plus the lower bound on every oriented overlap equal to its exact cutoff-conditioned arithmetic count. Since I<=9 and P>=1, V<=8. Put left17 and right13 together, put each remaining incidence token on its own row, and leave seven rows empty. This achieves8 and satisfies every overlap constraint.

Thus the exact maxima are (15,15,9,8), and the twin lower bounds are (0,0,6,7). Feasible witnesses in AGGREGATES.json establish each claimed optimum, so no optimizer or unproved integrality assertion is used.

## 5. Exactness and the tautology boundary

For the actual arithmetic rows, H is the exact incidence total and J is the exact double-row count. The identity gives T=R-H+J=7. C4 therefore recovers the exact number of twins from exact sufficient aggregate statistics. It does not locate them without further row information. Although C3 already forces a survivor without reading the complete named incidence matrix, its capacities were computed by exact counting-sieve inclusion-exclusion. This is not a free prediction from the visual clock geometry. C4 is exact union counting in a degree-two situation; there is no unexplained cancellation or new asymptotic estimate.

The seven audited twin centers are 1428,1452,1482,1488,1608,1620,1668. Their endpoint pairs are (1427,1429),(1451,1453),(1481,1483),(1487,1489),(1607,1609),(1619,1621),(1667,1669).

## 6. Evidence, provenance, and scope

Original packet: PRIME_NUMBER_AND_ULAM_SPIRAL_RESEARCH/outputs/cover_null_v1, with cover_null_v1.py and verify_cover_null_v1.py in its project root. Those bytes remain unchanged. The historical packet's own files do not establish a verification timestamp; a September19 conversation timestamp is a separately recovered source lead, not a date inferred from this audit. E035 and the proposed family021 release identity are unresolved.

The November2 reproduction first froze PROTOCOL.json and the two new implementations against twelve original evidence files. A new aggregate CRT implementation then locked its result before opening named active incidences. A separate implementation, importing neither generator nor original runner, used direct trial division and row enumeration to verify all capacities, all42 overlaps, every witness, and all prime pairs. Both use the same Python integer runtime; this is method-independent internal replication, not an independent third-party review. Parent-coordinated proof review and literature review remain separate.

The first broader saved-record audit failed because it incorrectly attributed all644 combined bands to v2. The retained FAILED_AUDIT_V1.txt and verify.py record that failure. The corrected portable verifier checks the disjoint143-band v1 plus501-band v2 union, reproducing saved totals R=362803, guaranteed twins72196, actual twins130459. This is a consistency audit of archived records, NOT a fresh arithmetic verification of all644 bands. No broad search or old runner was executed.

The finite lemma is standard inclusion-exclusion. Connections to Bonferroni/Hunter covering bounds and Jacobsthal covering formulations require comparison of exact definitions; no novelty or E035 equivalence is asserted here. Neither the finite example nor archived bands imply a uniform Jacobsthal bound, infinitely many twins, predictive advantage, or faster prime enumeration. A publishable mathematical claim beyond an expository/reproducibility note is not established by this packet alone.
