# Platform portability correction, v2

Independent Linux review of v1 passed arithmetic but failed reproduce.py byte comparisons: delivered expected JSON had Windows CRLF while Linux regenerated LF. The original v1 folder, ZIP, and prior archived version remain preserved. V1 was locally Windows-reproduced only; it was not cross-platform validated.

V2 explicitly passes newline="\n" to every runtime JSON output write in generate_portable.py and verify_portable.py. Expected JSON files and new documentation are UTF-8/LF. Archived evidence snapshots retain their original bytes. AGGREGATES_LOCK.json and PORTABLE_FREEZE.json are regenerated. Byte comparisons remain strict; no weakening to semantic comparisons. Arithmetic code, fixture, capacities, overlaps and witnesses are unchanged.

Parent-coordinated Linux revalidation is pending until separately reported. Local Windows rerun is recorded in V2_VALIDATION.json. No independent-review pass should be inferred from creating this version.
