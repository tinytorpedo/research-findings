# Audit status, 2026-11-02

PASS: fresh aggregate CRT and separate direct enumeration implementations agree on the known37-41 fixture. The portable package was then copied by reproduce.py to a fresh temporary destination and both implementations re-executed. AGGREGATES.json and POST_LOCK_ROWS.json matched byte-for-byte. All four relaxed witnesses satisfy their information levels and attain the proved upper bounds. Standard-library Python3.12.14; no package installation, solver or broad search.

Executed commands (from this packet directory, using the available Python interpreter):

    python -B generate.py
    python -B verify.py
    python -B prepare_portable.py
    python -B verify_portable.py
    python -B make_tables.py
    python -B reproduce.py NEW_REPRODUCTION_DIRECTORY

The initial verify.py run failed only at its incorrect644-band-v2 membership assertion, after the one-band checks passed. FAILED_AUDIT_V1.txt records it; verify.py is retained unchanged. A packaging one-liner had a PowerShell parse error, executing no Python; its subsequent attempted verifier invocation found no file. The explicit prepare_portable.py replaced that failed packaging attempt. No uncertain background process remains.

During manuscript/table checking, an unsaved numerical overlap description was corrected: the actual unique overlap is left17/right13 at1650, not left13/right19. The machine-readable calculations were correct throughout. The corrected table renderer derives/checks the overlap from AGGREGATES.json. The initial commentary's50 raw centers was corrected to51; all machine results use51.

Arithmetic constraints checked: p37 and q41 consecutive; y11 has11^3<=1680<12^3; both endpoints lie STRICTLY between37^2 and41^2; center1680 is excluded. Cube-root roughness alone is not claimed sufficient for the one-active-clock property outside this prime-square band. The proof uses active primes <=p, distinct-factor classification, and consecutiveness.

Internal method-independent reproduction is complete. Independent human/agent proof review and literature assessment are parent-coordinated and are NOT claimed complete here. General covering lemma is elementary degree-two inclusion-exclusion; Costello-Watts and other historical covering literature may already contain closely related formulations. This packet does not establish theorem novelty, E035 identity or a uniform Jacobsthal bound.

Broad archive audit:143 v1 bands plus501 v2 bands, unique(p,q) keys; only saved-record consistency checked, NOT a new arithmetic verification of644 bands. All fifteen original source/evidence inputs copied for portable provenance retain matching SHA256 bytes. No original, prior result or frozen review was edited.

Resource evidence: initial aggregate stage recorded0.0281499000 seconds in GENERATOR_RUN.json; first successful direct audit0.0956749001 seconds in VERIFICATION.json. Fresh portable rerun's direct audit reported0.1933949001 seconds. These are single tiny wall-time observations, not comparisons, CPU measurements or RAM measurements. No peak memory measurement was made.

Files were created only in the authorized workspace and a new temporary reproduction directory. The source archive project was read-only. Nothing was externally published or shared.
