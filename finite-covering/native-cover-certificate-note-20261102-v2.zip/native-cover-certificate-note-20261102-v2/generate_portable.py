"""Fresh aggregate-only reproduction. Does not import the historical runner."""
import hashlib,itertools,json,math,time,platform,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
SRC=HERE/'archive'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,v):
 p=HERE/n
 if p.exists(): raise FileExistsError(p)
 p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')
def primes(n): return [k for k in range(2,n+1) if all(k%d for d in range(2,math.isqrt(k)+1))]
def crt(congs):
 a,h=0,1
 for b,r in congs:
  a=(a+h*((b-a)*pow(h,-1,r)%r))%(h*r); h*=r
 return a,h
def count(congs):
 a,h=crt([(0,6)]+congs)
 return (1674-a)//h-(1373-a)//h
def rough(forced):
 return sum((-1)**len(t)*count(forced+t) for choices in itertools.product((0,1,-1),repeat=3)
            for t in [[(v,r) for v,r in zip(choices,[5,7,11]) if v]])
def main():
 start=time.perf_counter()
 frozen=json.loads((HERE/'PORTABLE_FREEZE.json').read_text())
 for rel,digest in frozen['new_inputs'].items(): assert sha(HERE/rel)==digest
 for rel,digest in frozen['original_inputs'].items(): assert sha(SRC/rel)==digest
 small=[5,7,11]; clocks=[13,17,19,23,29,31,37]
 cohort=[m for m in range(1374,1675,6) if all((m-1)%r and (m+1)%r for r in small)]
 R=rough([]); assert R==len(cohort)==15
 raw={(r,s):count([(s,r)]) for r in clocks for s in (1,-1)}
 cap={(r,s):rough([(s,r)]) for r in clocks for s in (1,-1)}
 pair={(r,s):rough([(1,r),(-1,s)]) for r in clocks for s in clocks if r!=s}
 H=sum(cap.values()); J=sum(pair.values())
 bounds=[R,min(R,sum(raw.values())),min(R,sum(raw.values()),H),min(R,sum(raw.values()),H,H-J)]
 def singles(c):
  hits=[[[r,s]] for (r,s),v in sorted(c.items()) for _ in range(v)][:R]
  return hits+[[] for _ in range(R-len(hits))]
 ws=[[[[13,1]] for _ in range(R)],singles(raw),singles(cap)]
 rem=cap.copy(); w=[]
 for (r,s),v in sorted(pair.items()):
  w += [[[r,1],[s,-1]] for _ in range(v)]
  rem[r,1]-=v; rem[s,-1]-=v
 assert min(rem.values())>=0
 w += [[[r,s]] for (r,s),v in sorted(rem.items()) for _ in range(v)]
 assert len(w)<=R
 ws.append(w+[[] for _ in range(R-len(w))])
 data={'p':37,'q':41,'X':1680,'y':11,'lo':1374,'hi':1674,'raw_population':51,'R':R,'cohort':cohort,
       'active_primes':clocks,'raw_sum':sum(raw.values()),'H':H,'J':J,'coverage_maxima':bounds,
       'twin_lower_bounds':[R-v for v in bounds],
       'capacities':[{'prime':r,'side':'left' if s==1 else 'right','residue':s,'raw':raw[r,s],'conditioned':cap[r,s]} for r,s in raw],
       'positive_oriented_overlaps':[{'left':r,'right':s,'count':v} for (r,s),v in pair.items() if v],
       'all_oriented_overlaps':[{'left':r,'right':s,'count':v} for (r,s),v in pair.items()],
       'relaxed_witnesses':ws}
 put('AGGREGATES.json',data);put('AGGREGATES_LOCK.json',{'sha256':sha(HERE/'AGGREGATES.json')})
 # Only now inspect completed named-row divisibility and primality.
 rows=[]
 for m in cohort:
  left=[r for r in clocks if (m-1)%r==0];right=[r for r in clocks if (m+1)%r==0]
  rows.append({'center':m,'left_endpoint':m-1,'right_endpoint':m+1,'left_clocks':left,'right_clocks':right})
 put('POST_LOCK_ROWS.json',rows)
 put('GENERATOR_RUN.json',{'wall_seconds':time.perf_counter()-start,'python':sys.version,'platform':platform.platform(),'command':'python -B generate_portable.py','scope':'one known band; aggregates locked before named active incidences opened'})
 print(json.dumps({k:data[k] for k in ('R','raw_sum','H','J','coverage_maxima')}))
if __name__=='__main__': main()
