# Covering null v1

Band 37–41; X=1680; y=11; 15 survivor rows; 7 active clocks.

| Level | Information added | Exact maximum coverage | Guaranteed twins | Outcome |
|---|---|---:|---:|---|
| 1 | Row alphabet | 15 | 0 | null survives |
| 2 | Raw clock-side capacities | 15 | 0 | null survives |
| 3 | Cutoff-conditioned aggregate capacities | 9 | 6 | certificate succeeds |
| 4 | Forced opposite-clock overlaps | 8 | 7 | certificate succeeds |

Raw capacity sum: 31. Conditioned H=9. Forced J=1. Post-lock audit: T=7.

Every upper bound is matched by a checked relaxed assignment. Witnesses are not claims of arithmetic realizability at their named addresses.

The first certificate uses exact aggregate incidence counts obtained by CRT inclusion-exclusion. The last level obtains the exact support count from exact H and J. This is a counting-sieve certificate without completed address assignments, not evidence of computational advantage, a new general theorem, or historically unseen validation.

Reproduce in a fresh copy/output location: python cover_null_v1.py freeze; then python cover_null_v1.py run. Existing artifacts are never overwritten. SPEC and runner are hashed before execution; RESULTS is hashed before the completed-incidence audit.
