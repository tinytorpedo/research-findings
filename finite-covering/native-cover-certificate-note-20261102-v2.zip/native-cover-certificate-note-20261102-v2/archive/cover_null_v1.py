"""Exact covering relaxation experiment; standard library only. See SPEC.json."""
import hashlib
import itertools
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs' / 'cover_null_v1'

def save(name, value):
    path = OUT / name
    if path.exists():
        raise FileExistsError(path)
    path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n', encoding='utf-8')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def primes(n):
    return [a for a in range(2,n+1) if all(a%d for d in range(2,math.isqrt(a)+1))]

def crt_count(lo, hi, congruences):
    # Incremental exact CRT; all moduli here are distinct primes except initial 6.
    a, modulus = 0, 1
    for residue, prime in congruences:
        a += modulus * (((residue-a)*pow(modulus,-1,prime)) % prime)
        modulus *= prime
        a %= modulus
    return (hi-a)//modulus - (lo-1-a)//modulus

def conditioned_count(lo, hi, forced, small):
    # Expand product_l (1 - 1[m=1 mod l] - 1[m=-1 mod l]).
    total = 0
    for choices in itertools.product((0,-1,1), repeat=len(small)):
        terms = [(s,l) for s,l in zip(choices,small) if s]
        total += (-1)**len(terms) * crt_count(lo,hi,[(0,6)]+forced+terms)
    return total

def freeze():
    OUT.mkdir(parents=True,exist_ok=True)
    spec = dict(band=[37,41], cutoff='floor_cuberoot(q*q-1)',
      selection='Previously published fixture, selected for hand-auditable mechanics; not unseen.',
      levels=[
        'L1: zero, left-only, right-only, opposite distinct-clock pair; one state per named survivor.',
        'L2: retain L1; per clock-side upper capacities from CRT counts in unsieved center interval.',
        'L3: retain L2; tighten capacities by cutoff inclusion-exclusion CRT aggregate counts.',
        'L4: retain L3; lower-bound each oriented opposite-clock overlap by its cutoff-conditioned CRT count.'],
      allowed='Construct named cohort using primes <=y. Constraint generation may count CRT progressions over whole interval, including cutoff inclusion-exclusion. It may not query active-clock divisibility at named rows, factor endpoints, or read atlas/fixture outputs.',
      prohibited='No completed O or primality labels before results are saved and hashed. No per-row active residues or singleton interval counts.',
      soundness='Actual clock-side occupancies equal conditioned aggregate capacities and do not exceed raw capacities. Actual oriented pair occupancies equal CRT pair counts. Cube depth bounds endpoint degree by one. All constraints are cumulative.',
      optimization='Construct relaxed assignments. Upper bound L1 R; L2 min(R,sum raw capacities); L3 min(R,sum conditioned capacities); L4 min(previous bounds,sum conditioned capacities - sum forced pair counts). Claim optimum only when verified witness attains bound.',
      information_limit='L3 and L4 disclose exact aggregate incidence statistics through a counting sieve. This tests loss of address alignment, not an advantage over sieving or a new general twin theorem.',
      audit='After freezing results, independently enumerate all active incidences and primality to audit arithmetic counts and soundness. Audit data cannot generate or revise constraints.')
    save('SPEC.json',spec)
    save('FREEZE.json',{'spec_sha256':digest(OUT/'SPEC.json'),'runner_sha256':digest(Path(__file__))})

def run():
    frozen=json.loads((OUT/'FREEZE.json').read_text())
    assert frozen['spec_sha256']==digest(OUT/'SPEC.json')
    assert frozen['runner_sha256']==digest(Path(__file__))
    p,q=37,41
    X=q*q-1
    y=0
    while (y+1)**3<=X:y+=1
    lo,hi=p*p+5,q*q-7
    small=[r for r in primes(y) if r>3]
    clocks=[r for r in primes(p) if r>y]
    cohort=[m for m in range(lo,hi+1,6) if all((m-1)%l and (m+1)%l for l in small)]
    R=len(cohort)
    assert conditioned_count(lo,hi,[],small)==R
    raw={(r,s):crt_count(lo,hi,[(0,6),(s,r)]) for r in clocks for s in (-1,1)}
    cap={(r,s):conditioned_count(lo,hi,[(s,r)],small) for r in clocks for s in (-1,1)}
    # s=-1 means m+1 divisible (right); s=1 means m-1 divisible (left).
    pair={(r,s):conditioned_count(lo,hi,[(1,r),(-1,s)],small)
          for r in clocks for s in clocks if r!=s}
    assert all(0<=cap[k]<=raw[k] for k in cap)
    H=sum(cap.values());J=sum(pair.values())
    def single_witness(capacity):
        tokens=[[r,s] for (r,s),n in sorted(capacity.items()) for _ in range(n)]
        return [[token] for token in tokens[:R]] + [[] for _ in range(max(0,R-len(tokens)))]
    assignments=[[[[clocks[0],1]] for _ in cohort], single_witness(raw),single_witness(cap)]
    remaining=cap.copy(); rows=[]
    for (r,s),n in sorted(pair.items()):
        rows += [[[r,1],[s,-1]] for _ in range(n)]
        remaining[r,1]-=n;remaining[s,-1]-=n
    assert min(remaining.values())>=0
    rows += [[[r,s]] for (r,s),n in sorted(remaining.items()) for _ in range(n)]
    assert len(rows)<=R, 'This fixed witness construction requires coverage bound <=R'
    rows += [[] for _ in range(R-len(rows))]
    assignments.append(rows)
    bounds=[R,min(R,sum(raw.values())),min(R,sum(raw.values()),H),min(R,sum(raw.values()),H,H-J)]
    results=[]
    for level,(assignment,bound) in enumerate(zip(assignments,bounds),1):
        # Independently count witness usage; no arithmetic row-address tests allowed.
        usage={k:0 for k in cap}; overlaps={k:0 for k in pair}
        assert len(assignment)==R
        for row in assignment:
            assert len(row)<=2
            for r,s in row:
                assert r in clocks and s in (-1,1)
                usage[r,s]+=1
            if len(row)==2:
                assert row[0][0]!=row[1][0] and row[0][1]!=row[1][1]
                left=next(r for r,s in row if s==1)
                right=next(r for r,s in row if s==-1)
                overlaps[left,right]+=1
        if level>=2:assert all(usage[k]<=raw[k] for k in usage)
        if level>=3:assert all(usage[k]<=cap[k] for k in usage)
        if level>=4:assert all(overlaps[k]>=pair[k] for k in pair)
        covered=sum(bool(row) for row in assignment)
        assert covered==bound
        results.append(dict(level=level,certified_upper_bound=bound,verified_witness_coverage=covered,
            exact_optimum=covered,twin_lower_bound=R-bound,status='null survives' if covered==R else 'certificate succeeds',
            named_witness=[dict(center=m,hits=row) for m,row in zip(cohort,assignment)]))
    report=dict(p=p,q=q,X=X,y=y,raw_centers=len(range(lo,hi+1,6)),R=R,cohort=cohort,clocks=clocks,
      raw_capacity_sum=sum(raw.values()),H=H,J=J,
      capacities=[dict(clock=r,residue=s,raw=raw[r,s],conditioned=cap[r,s]) for r,s in cap],
      forced_overlaps=[dict(left=r,right=s,count=n) for (r,s),n in pair.items() if n],levels=results)
    save('RESULTS.json',report)
    save('RESULTS_LOCK.json',{'results_sha256':digest(OUT/'RESULTS.json')})
    # Only now open completed incidences, using a separate enumeration computation.
    actual=[[[r,s] for r in clocks for s in (-1,1) if m%r==s%r] for m in cohort]
    for row in actual:
        assert len(row)<=2
        assert len(set(s for r,s in row))==len(row)
    actual_cap={(r,s):sum([r,s] in row for row in actual) for r,s in cap}
    actual_pair={(r,s):sum([r,1] in row and [s,-1] in row for row in actual) for r,s in pair}
    assert actual_cap==cap and actual_pair==pair
    twins=[m for m,row in zip(cohort,actual) if not row]
    prime_set=set(primes(X))
    assert twins==[m for m in cohort if m-1 in prime_set and m+1 in prime_set]
    assert all(R-b<=len(twins) for b in bounds)
    assert digest(OUT/'RESULTS.json')==json.loads((OUT/'RESULTS_LOCK.json').read_text())['results_sha256']
    save('POST_LOCK_AUDIT.json',dict(actual_incidence=actual,twin_centers=twins,T=len(twins),
        all_aggregate_counts_match=True,all_witnesses_verified=True,all_upper_bounds_exact=True))
    lines=['# Covering null v1','',f'Band {p}–{q}; X={X}; y={y}; {R} survivor rows; {len(clocks)} active clocks.','',
      '| Level | Information added | Exact maximum coverage | Guaranteed twins | Outcome |',
      '|---|---|---:|---:|---|']
    names=['Row alphabet','Raw clock-side capacities','Cutoff-conditioned aggregate capacities','Forced opposite-clock overlaps']
    for result,name in zip(results,names):
        lines.append(f"| {result['level']} | {name} | {result['exact_optimum']} | {result['twin_lower_bound']} | {result['status']} |")
    lines += ['',f'Raw capacity sum: {sum(raw.values())}. Conditioned H={H}. Forced J={J}. Post-lock audit: T={len(twins)}.',
      '', 'Every upper bound is matched by a checked relaxed assignment. Witnesses are not claims of arithmetic realizability at their named addresses.',
      '', 'The first certificate uses exact aggregate incidence counts obtained by CRT inclusion-exclusion. The last level obtains the exact support count from exact H and J. This is a counting-sieve certificate without completed address assignments, not evidence of computational advantage, a new general theorem, or historically unseen validation.',
      '', 'Reproduce in a fresh copy/output location: python cover_null_v1.py freeze; then python cover_null_v1.py run. Existing artifacts are never overwritten. SPEC and runner are hashed before execution; RESULTS is hashed before the completed-incidence audit.']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({k:report[k] for k in ('R','raw_capacity_sum','H','J')},indent=2))
    print('\n'.join(lines))

if __name__=='__main__':
    {'freeze':freeze,'run':run}[sys.argv[1]]()
