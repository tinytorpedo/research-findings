"""Independent certificate auditor; never imports the generating program."""
from pathlib import Path
import json
import hashlib
from collections import Counter

root=Path(__file__).resolve().parent
out=root/'outputs'/'cover_null_v1'
load=lambda name:json.loads((out/name).read_text(encoding='utf-8'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
freeze=load('FREEZE.json')
assert sha(root/'cover_null_v1.py')==freeze['runner_sha256']
assert sha(out/'SPEC.json')==freeze['spec_sha256']
assert sha(out/'RESULTS.json')==load('RESULTS_LOCK.json')['results_sha256']
d=load('RESULTS.json')
p,q,y=d['p'],d['q'],d['y']
isprime=lambda n:n>=2 and all(n%a for a in range(2,int(n**0.5)+1))
assert isprime(p) and isprime(q) and not any(isprime(n) for n in range(p+1,q))
assert y**3<=q*q-1<(y+1)**3
base=list(range(p*p+5,q*q-6,6))
small=[n for n in range(2,y+1) if isprime(n)]
cohort=[m for m in base if all((m-1)%a and (m+1)%a for a in small)]
clocks=[n for n in range(y+1,p+1) if isprime(n)]
assert cohort==d['cohort'] and clocks==d['clocks']
raw=Counter((r,s) for m in base for r in clocks for s in (-1,1) if (m-s)%r==0)
cap=Counter((r,s) for m in cohort for r in clocks for s in (-1,1) if (m-s)%r==0)
pairs=Counter((r,s) for m in cohort for r in clocks for s in clocks if r!=s and (m-1)%r==0 and (m+1)%s==0)
for x in d['capacities']:
    key=x['clock'],x['residue']
    assert x['raw']==raw[key] and x['conditioned']==cap[key]
assert {(x['left'],x['right']):x['count'] for x in d['forced_overlaps']}==dict(pairs)
R=len(cohort);H=sum(cap.values());J=sum(pairs.values())
bounds=[R,min(R,sum(raw.values())),min(R,sum(raw.values()),H),min(R,sum(raw.values()),H,H-J)]
for result,bound in zip(d['levels'],bounds):
    level=result['level'];usage=Counter();overlap=Counter();coverage=0
    assert [x['center'] for x in result['named_witness']]==cohort
    for entry in result['named_witness']:
        hits=[tuple(h) for h in entry['hits']]
        assert len(hits)<=2 and all(r in clocks and s in (-1,1) for r,s in hits)
        if len(hits)==2:
            assert len({r for r,s in hits})==2 and {s for r,s in hits}=={-1,1}
            overlap[next(r for r,s in hits if s==1),next(r for r,s in hits if s==-1)]+=1
        usage.update(hits);coverage+=bool(hits)
    if level>=2:assert all(n<=raw[k] for k,n in usage.items())
    if level>=3:assert all(n<=cap[k] for k,n in usage.items())
    if level>=4:assert all(overlap[k]>=n for k,n in pairs.items())
    assert coverage==bound==result['certified_upper_bound']==result['exact_optimum']
    assert result['twin_lower_bound']==R-bound
twins=[m for m in cohort if isprime(m-1) and isprime(m+1)]
assert len(twins)==R-H+J
verification=dict(hashes_pass=True,independent_arithmetic_audit_pass=True,witnesses_pass=True,
    exact_optima=bounds,T=len(twins),twin_centers=twins,
    note='Verifier deliberately uses completed arithmetic only after locked experiment, to audit soundness; it is not the restricted constraint generator.')
(out/'INDEPENDENT_VERIFICATION.json').write_text(json.dumps(verification,indent=2)+'\n',encoding='utf-8')
print(json.dumps(verification,indent=2))
