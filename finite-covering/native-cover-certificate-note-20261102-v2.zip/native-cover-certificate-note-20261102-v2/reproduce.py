"""Re-run portable generator and verifier in a NEW destination, never overwrite."""
import argparse,json,shutil,subprocess,sys,hashlib
from pathlib import Path
base=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('destination');a=ap.parse_args()
dest=Path(a.destination).resolve()
if dest.exists(): raise FileExistsError('Use a destination that does not exist')
f=json.loads((base/'PORTABLE_FREEZE.json').read_text())
for name,h in f['new_inputs'].items(): assert hashlib.sha256((base/name).read_bytes()).hexdigest()==h
for name,h in f['original_inputs'].items(): assert hashlib.sha256((base/'archive'/name).read_bytes()).hexdigest()==h
dest.mkdir(parents=True)
for name in ['PROTOCOL.json','PORTABLE_FREEZE.json','generate_portable.py','verify_portable.py']:
 shutil.copyfile(base/name,dest/name)
shutil.copytree(base/'archive',dest/'archive')
subprocess.run([sys.executable,'-B',str(dest/'generate_portable.py')],cwd=dest,check=True)
subprocess.run([sys.executable,'-B',str(dest/'verify_portable.py')],cwd=dest,check=True)
assert (dest/'AGGREGATES.json').read_bytes()==(base/'AGGREGATES.json').read_bytes()
assert (dest/'POST_LOCK_ROWS.json').read_bytes()==(base/'POST_LOCK_ROWS.json').read_bytes()
print('PASS: fresh portable reproduction matches all aggregate and row bytes')
