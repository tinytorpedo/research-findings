# Portable companion packet

Scope: one retrospective fixed-band certificate, not a new search or a uniform Jacobsthal theorem. Read RESEARCH_NOTE.md, TABLES.md, PROTOCOL.json and VERIFICATION.json. Parent-coordinated external review is separate; no third-party review is claimed by these scripts.

Requirements: Python3.10 or later, standard library only. No installs, network, solver, environment variables or C-drive paths are needed for the portable reproduction. Work on a copy, or select a new output destination:

    python -B reproduce.py ../cover-reproduction-fresh

The destination must not exist. This wrapper verifies frozen input hashes, copies portable inputs into that new destination, runs:

    python -B generate_portable.py
    python -B verify_portable.py

and compares the new aggregate and named-row output bytes with the delivered outputs. The generator refuses to overwrite results. The archive/ directory contains byte-for-byte original evidence snapshots; scripts do not execute archived source. PORTABLE_FREEZE.json records their original relative paths and hashes. PRE_RUN_FREEZE.json records the initial retrospective claim/code/input freeze. SHA256SUMS.json seals the complete delivered packet.

Primary outputs: AGGREGATES.json (all14 capacities,42 overlaps, four attaining witnesses), AGGREGATES_LOCK.json, POST_LOCK_ROWS.json (15 named rows), VERIFICATION.json, GENERATOR_RUN.json. Expected R15,H9,J1, raw sum31; coverage maxima15/15/9/8; lower bounds0/0/6/7; seven listed twin centers.

Historical absolute-path development scripts, the initial failed verifier and initial PRE_RUN_FREEZE.json remain in the preserved v1 packet identified by V1_REFERENCE.json; they are intentionally omitted from this portable v2 subset. FAILED_AUDIT_V1.txt explains that earlier failure and repair. No v1 or original source artifact was edited. Use only the portable entry points above.

The broader644-band result is only a saved-record consistency audit today, split into143 v1 and501 v2 bands. Its evidence copies are included so the verifier can check disjointness and totals. The full original broader arithmetic generators are not claimed reproduced.

Runtime measurements describe these tiny single runs only, not speed comparisons or peak memory. No external publication, new prime prediction, source-energy improvement, or native I37/I54 transfer is part of this packet.

V2 portability: runtime JSON writes explicitly use UTF-8/LF; strict byte comparisons are retained. See PORTABILITY_CORRECTION.md. Current entry points remain reproduce.py, generate_portable.py and verify_portable.py. Linux revalidation is pending, not inferred from a Windows pass.
