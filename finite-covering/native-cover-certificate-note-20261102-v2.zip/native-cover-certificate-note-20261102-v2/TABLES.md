# Exact fixed-band tables

Inclusive center interval1374..1674 in steps of6; 51 raw centers. The center1680 is EXCLUDED, since its right endpoint1681=41^2 is composite.

## Capacities

| Prime | Raw left | Raw right | Conditioned left | Conditioned right |
|---|---:|---:|---:|---:|
| 13 | 4 | 4 | 1 | 1 |
| 17 | 3 | 3 | 1 | 2 |
| 19 | 2 | 3 | 1 | 1 |
| 23 | 2 | 2 | 1 | 0 |
| 29 | 2 | 1 | 0 | 0 |
| 31 | 2 | 1 | 1 | 0 |
| 37 | 1 | 1 | 0 | 0 |

Raw total31; conditioned total9. Only positive oriented overlap: left17/right13, count1, at center1650. All other41 oriented counts are zero.

## Retained named rows (post-lock direct arithmetic audit)

| Center | Left endpoint | Right endpoint | Left active prime | Right active prime | Twin |
|---|---:|---:|---|---|---|
| 1410 | 1409 | 1411 | - | 17 | no |
| 1428 | 1427 | 1429 | - | - | yes |
| 1452 | 1451 | 1453 | - | - | yes |
| 1458 | 1457 | 1459 | 31 | - | no |
| 1470 | 1469 | 1471 | 13 | - | no |
| 1482 | 1481 | 1483 | - | - | yes |
| 1488 | 1487 | 1489 | - | - | yes |
| 1500 | 1499 | 1501 | - | 19 | no |
| 1512 | 1511 | 1513 | - | 17 | no |
| 1542 | 1541 | 1543 | 23 | - | no |
| 1578 | 1577 | 1579 | 19 | - | no |
| 1608 | 1607 | 1609 | - | - | yes |
| 1620 | 1619 | 1621 | - | - | yes |
| 1650 | 1649 | 1651 | 17 | 13 | no |
| 1668 | 1667 | 1669 | - | - | yes |

## Attaining relaxed assignments

Entries below are abstract row states; their association to a center is only a label, NOT an arithmetic assertion. Lr means clockr on left; Rr means clockr on right.

| Row label | C1 witness | C2 witness | C3 witness | C4 witness |
|---|---|---|---|---|
| 1410 | L13 | R13 | R13 | L17+R13 |
| 1428 | L13 | R13 | L13 | L13 |
| 1452 | L13 | R13 | R17 | R17 |
| 1458 | L13 | R13 | R17 | R17 |
| 1470 | L13 | L13 | L17 | R19 |
| 1482 | L13 | L13 | R19 | L19 |
| 1488 | L13 | L13 | L19 | L23 |
| 1500 | L13 | L13 | L23 | L31 |
| 1512 | L13 | R17 | L31 | empty |
| 1542 | L13 | R17 | empty | empty |
| 1578 | L13 | R17 | empty | empty |
| 1608 | L13 | L17 | empty | empty |
| 1620 | L13 | L17 | empty | empty |
| 1650 | L13 | L17 | empty | empty |
| 1668 | L13 | R19 | empty | empty |

Coverage maxima:15,15,9,8. Empty-row lower bounds:0,0,6,7.
