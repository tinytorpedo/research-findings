"""AI-assisted independent audit; Python standard library only. Run without -O."""
import argparse, json, math, pathlib, hashlib, shutil, subprocess, sys, zipfile
ap=argparse.ArgumentParser()
ap.add_argument('core_zip',type=pathlib.Path)
ap.add_argument('destination',type=pathlib.Path,help='New nonexistent directory')
a=ap.parse_args()
assert sys.flags.optimize==0, 'Assertions must be enabled'
assert hashlib.sha256(a.core_zip.read_bytes()).hexdigest()=='e8b74a6004c29714750f75d9b1ab0b048d4ee27a228d16138c182cf5c88d5e66'
P=a.destination.resolve()
if P.exists(): raise FileExistsError('Use a new destination')
P.mkdir(parents=True)
with zipfile.ZipFile(a.core_zip) as z:
 for member in z.infolist():
  target=(P/'core'/member.filename).resolve()
  assert target.is_relative_to((P/'core').resolve()), 'Unsafe ZIP member'
 z.extractall(P/'core')
core=P/'core/native-cover-certificate-note-20261102-v2'
fresh=P/'fresh-run'
run=subprocess.run([sys.executable,'-B',str(core/'reproduce.py'),str(fresh)],capture_output=True,text=True)
(P/'LINUX_REPRODUCTION.log').write_text(run.stdout+run.stderr,encoding='utf-8')
assert run.returncode==0, run.stderr
print('Core reproduce.py strict byte comparison PASS')
# Independent Eratosthenes, rather than trial division.
sieve=[True]*1682;sieve[0]=sieve[1]=False
for r in range(2,math.isqrt(1681)+1):
 if sieve[r]:
  for k in range(r*r,1682,r):sieve[k]=False
D=[c for c in range(1682) if c%6==0 and 37**2<c-1<c+1<41**2]
small=[r for r in range(2,12) if sieve[r]];active=[r for r in range(12,38) if sieve[r]]
A=[c for c in D if all((c*c-1)%r for r in small)]
agg=json.loads((fresh/'AGGREGATES.json').read_text()); rows=json.loads((fresh/'POST_LOCK_ROWS.json').read_text())
assert len(D)==51 and (D[0],D[-1])==(1374,1674) and 1680 not in D
assert A==agg['cohort']
hits={c:([r for r in active if (c-1)%r==0],[r for r in active if (c+1)%r==0]) for c in A}
assert [(c,l,r) for c,(l,r) in hits.items() if l and r]==[(1650,[17],[13])]
T=[c for c in A if sieve[c-1] and sieve[c+1]]
assert len(T)==7 and sum(len(l)+len(r) for l,r in hits.values())==9
print('Independent sieve/boundary/orientation audit PASS', {'D':len(D),'A':len(A),'T':T,'overlap':[1650,17,13]})
# Mutate data and update aggregate lock so rejection tests arithmetic, not just checksum.
mutations={
 'wrong_overlap_orientation':lambda d: [a.update(count=0 if (a['left'],a['right'])==(17,13) else 1 if (a['left'],a['right'])==(13,17) else a['count']) for a in d['all_oriented_overlaps']],
 'wrong_capacity':lambda d:d['capacities'][0].update(conditioned=d['capacities'][0]['conditioned']+1),
 'boundary_include1680':lambda d:d['cohort'].append(1680),
 'same_clock_pair':lambda d:d['relaxed_witnesses'][3].__setitem__(0,[[17,1],[17,-1]])}
for name,change in mutations.items():
 dest=P/('mutation-'+name);shutil.copytree(fresh,dest)
 (dest/'VERIFICATION.json').unlink()
 d=json.loads((dest/'AGGREGATES.json').read_text());change(d)
 data=json.dumps(d).encode();(dest/'AGGREGATES.json').write_bytes(data)
 (dest/'AGGREGATES_LOCK.json').write_text(json.dumps({'sha256':hashlib.sha256(data).hexdigest()}))
 run=subprocess.run([sys.executable,'-B',str(dest/'verify_portable.py')],capture_output=True,text=True)
 assert run.returncode!=0 and 'AssertionError' in run.stderr
 print('Mutation rejection PASS:',name)
 (P/('mutation-'+name+'.log')).write_text(run.stdout+run.stderr)
