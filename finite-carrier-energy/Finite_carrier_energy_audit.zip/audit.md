# Retrospective independent analytic review

## Verdict

No substantive gap was found in the recovered complete bare-source bound

sum_(1<N<=T) |F_T(N)|² = O(T log⁶ T),

for the exact source and cutoffs stated in the manuscript, using the explicitly stated classical Möbius, Mertens-product and Chebyshev inputs. This conclusion concerns the bare arithmetic source. It does not establish native response transfer, full logarithmic exponent five, a sharp physical lower bound, or novelty relative to the literature.

The restricted October 27 exponent-five argument has correct displayed ownership, cross-term and aggregation bookkeeping. Its uniform all-cutoff conditioned joint-role norm estimate remains an explicit inherited hypothesis in this review; it has not been independently established here. That restricted theorem must not be presented as a complete exponent-five theorem.

## Material and deductions checked

The reviewer inspected the recovered original complete-six argument; the complete joint-first-order-row harmonic proof; the scalar coherent-moment argument; fixed-input and Abel-tail addendum; one-large-prime profile and carrier estimates; and two-large-prime coefficient collapse and repeated-carrier estimates. The full October 27 restricted argument and its marked-input statement were also inspected.

The main independently checked implications are:

- Exact physical support forces U²<s<=T/4 and 4<=m<U/8. The original short-carrier cutoff is automatic.
- The nonnegative carrier divisor mass is at most log²N. Weighted Cauchy cancels the original squared normalization before summation, costing only T(1+log U) times the signed cofactor harmonic square.
- The harmonic endpoint estimate retains the common boundary shift. Its kernel square integral is 5 and its explicit coefficient is 1536. Full row allocation and exclusion masses are retained; correction Euler products converge uniformly in degree and support.
- Local Gram moments were separately derived from the normalized one-prime measure, confirming the quoted basis and norms.
- The harmonic fifth moment, followed by the carrier estimate, gives zero-large-prime exponent six. The exact one-large-prime sector is O(T log²T); the two-large-prime sector is O(T log T), with repeated carriers retained. Since U³=8T, these three disjoint output sectors are exhaustive.
- October 27 complete-output ownership is distinct from internal role decomposition. The internal Z/J cross is O(M L^(9/2)); an overlapping exponent-six external field has only the generic O(M L^(11/2)) cross. The threshold A=(log x−log 2)/(4C*) is scale-dependent, not a fixed absolute constant.

## External theorem verification

The author-hosted manuscript of M. Ram Murty and Akshaa Vatwani, *A remark on a conjecture of Chowla*, Journal of the Ramanujan Mathematical Society 33(2) (2018), 111–123, was independently retrieved from [the author's publication copy](https://mrammurty-ai.github.io/chowla.pdf). Proposition 3, printed p.115/PDF p.5, agrees with the supplied statement. Fixing precision A=4 before the source scale varies and retaining only modulus q=1 is valid. The subsequent uniform Abel-tail and hyperbola arguments were checked.

This verifies the imported manuscript statement and its application. It is not an independent proof of the credited Siebert–Wolke theorem, nor a comparison with final publisher proofs. The journal's bibliographic record is [available here](https://www.mathjournals.org/jrms/2018-033-002/2018-033-002-001.html).

## Finite validation

The reviewer inspected and independently reran the included standard-library verifier at U=40 (T=8000) and U=80 (T=64000); both passed. The latter run reproduced 435 nonzero source outputs, 1298 ordered source histories and 688 ordered Gram terms in the final verifier version.

These are exact integer formal-log-polynomial checks of the finite zero-large-prime source identity and Gram algebra. They are internal replication, not independent third-party validation or a proof of asymptotic estimates. The endpoint mutation fixtures are synthetic detector checks, not arithmetic observations. The final Gram loop includes every output fiber formed by nonzero carrier and cofactor rows, including zero synthesized responses if present. The reviewer reran this final version at both scales; it passed, with zero such zero-response fibers present and the same reported counts. Thus these runs do not themselves exercise an actual zero-response Gram cancellation fiber.

No proof assistant was used. Finite counts, hashes and successful mutations do not certify the analytic theorem, the imported result, or the October 27 all-cutoff role hypothesis.
