FINITE CARRIER ENERGY AUDIT PACKET

Read Finite_carrier_energy.docx or the matching PDF first, then audit.md.
The bare-source sixth-power proof survives analytic review using the stated classical inputs. The repeated-decorator fifth-power refinement is conditional on the displayed inherited marked-role, physical-map, and core-mass inputs. No native or production transfer is claimed.

REPRODUCE EXACT FINITE CHECKS
Requires Python 3 standard library only. From this folder run:
  python3 verify_energy.py 40
  python3 verify_energy.py 80
Both should print status PASS and regenerate their matching JSON result.
The final loop tests every output reachable from nonzero K and D, including a zero response if one occurs; neither reviewed finite domain has such a zero-response fiber. Shared coefficient construction means this is an internal consistency test. Synthetic endpoint fixtures and the explicit gcd witness are not asymptotic evidence.

CONTENTS
- manuscript.txt: editable plain-text mathematical source
- DOCX and PDF: final typeset paper
- verify_energy.py and verification_results_40/80.json: runnable exact tests
- audit.md: retrospective analytic review and limits
- sources/: portable recovered research transcriptions, with personal paths removed
- provenance.json: historical original-source hash pins and external citation
- SHA256SUMS.json: hashes of actual distributed bytes

The text uses EQ for displayed equations and PAGE for intended page breaks. The manuscript has no dependency on the original computer. Historical exponent labels in source transcriptions remain unchanged. Sources are working notes, not published literature. This packet was prepared privately and has not been published.
