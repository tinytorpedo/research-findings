"""Exact finite source checks. Python 3 standard library only; no asymptotic certification."""
from collections import defaultdict, Counter
from math import gcd, isqrt
import json
from pathlib import Path
import sys
U=int(sys.argv[1]) if len(sys.argv)>1 else 40
assert U in (40,80), "Reviewed finite domains are U=40 and U=80"
T=U**3//8

def factor(n):
    out={}; p=2
    while p*p<=n:
        while n%p==0: out[p]=out.get(p,0)+1; n//=p
        p+=1
    if n>1: out[n]=out.get(n,0)+1
    return out

def mu(n):
    f=factor(n)
    return 0 if any(e>1 for e in f.values()) else (-1)**len(f)
def divs(n):
    return [d for d in range(1,isqrt(n)+1) if n%d==0 for d in ([d] if d*d==n else [d,n//d])]
def clean(d): return {k:v for k,v in d.items() if v}
def poly_add(dst, src, scale=1):
    for k,v in src.items(): dst[k]+=v*scale

def multiply(a,b):
    c=defaultdict(int)
    for k,v in a.items():
        for l,w in b.items(): c[tuple(sorted(k+l))]+=v*w
    return clean(c)

C={n:sum(mu(d) for d in divs(n) if d<=U)-(n==1) for n in range(1,T//4+1)}
f={n:v for n,v in C.items() if n>U and all(p<=U for p in factor(n)) and v}
assert all(C[n]==0 for n in range(1,U+1))
D=defaultdict(int)
for a,va in f.items():
    for b,vb in f.items():
        if a*b>T//4: break
        D[a*b]+=va*vb
D=clean(D)
assert D and min(D)>U*U
carriers={}
for n in range(2,T//(U*U)+1):
    ff=factor(n)
    if len(ff)==1: carriers[n]=next(iter(ff))
K=defaultdict(lambda:defaultdict(int))
for a,p in carriers.items():
    for b,q in carriers.items():
        if a*b<T/(U*U): K[a*b][tuple(sorted((p,q)))]+=1
K={m:clean(poly) for m,poly in K.items()}
# A separate wider inventory checks repeated prime-power carrier multiplicity.
def K_at(m):
    ans=defaultdict(int)
    for a in divs(m):
        b=m//a; fa,fb=factor(a),factor(b)
        if len(fa)==len(fb)==1: ans[tuple(sorted((next(iter(fa)),next(iter(fb)))))]+=1
    return clean(ans)
assert K_at(8)=={(2,2):2}
assert K_at(16)=={(2,2):3}
compressed=defaultdict(lambda:defaultdict(int)); histories=0
for m,poly in K.items():
    for s,v in D.items():
        if m*s<=T: poly_add(compressed[m*s],poly,v)
direct=defaultdict(lambda:defaultdict(int))
for a,p in carriers.items():
    for b,q in carriers.items():
        if b>U//2: continue
        for c,vc in f.items():
            for d,vd in f.items():
                n=a*b*c*d
                if n>T: break
                if n<=T:
                    direct[n][tuple(sorted((p,q)))]+=vc*vd; histories+=1
compressed={n:clean(p) for n,p in compressed.items() if clean(p)}
direct={n:clean(p) for n,p in direct.items() if clean(p)}
assert direct==compressed
assert all(len(factor(n))!=1 for n in direct)
# Compare exact signed polynomial squares to gcd-reparametrized Gram.
gram_terms=0; shared_gcd_terms=0
all_fibers=sorted({m*s for m in K for s in D if m*s<=T})
zero_fibers=0
for n in all_fibers:
    response=compressed.get(n,{})
    zero_fibers+=not bool(response)
    rows=[(m,D[n//m]) for m in K if n%m==0 and n//m in D]
    gram=defaultdict(int)
    for m1,v1 in rows:
        for m2,v2 in rows:
            d=gcd(m1,m2); a=m1//d; b=m2//d
            assert gcd(a,b)==1 and n%(d*a*b)==0
            k=n//(d*a*b)
            assert n//m1==b*k and n//m2==a*k
            poly_add(gram,multiply(K[m1],K[m2]),v1*v2); gram_terms+=1
            shared_gcd_terms+=gcd(d,a*b*k)>1
    assert clean(gram)==multiply(response,response)
# Exact algebraic witness for the forbidden extra coprimality restriction.
d,a,b,k=4,1,2,1
assert gcd(a,b)==1 and gcd(d,b)>1 and (d*a,d*b)==(4,8)
# Literal inclusive physical endpoint and nonzero signed cofactor witnesses.
if U==40:
    assert D.get(1764)==1 and D.get(1932)==-2 and D.get(2000,0)==0
# Synthetic projection fixture: demonstrates detector sensitivity, not source data.
fixture={U*U:7,U*U+1:-3,T//4:5,T//4+1:11}
strict={s:v for s,v in fixture.items() if U*U<s<=T//4}
wrong_lower={s:v for s,v in fixture.items() if U*U<=s<=T//4}
wrong_upper={s:v for s,v in fixture.items() if U*U<s<T//4}
assert strict!=wrong_lower and strict!=wrong_upper
# Source sign mutation must change at least one actual response.
wrong=defaultdict(lambda:defaultdict(int))
for m,p in K.items():
    for s,v in D.items():
        if m*s<=T: poly_add(wrong[m*s],p,abs(v))
assert any(clean(wrong[n])!=p for n,p in compressed.items())
result={'status':'PASS','U':U,'T':T,'cofactor_limit':T//4,'nonzero_long_role_coefficients':len(f),'nonzero_cofactor_coefficients':len(D),'nonzero_source_outputs':len(direct),'ordered_source_histories':histories,'ordered_Gram_terms':gram_terms,'zero_response_Gram_fibers':zero_fibers,'actual_Gram_terms_with_shared_d':shared_gcd_terms,'formal_log_polynomials':True,'signed_cofactor_witnesses':{str(next(s for s,v in D.items() if v>0)):next(v for v in D.values() if v>0),str(next(s for s,v in D.items() if v<0)):next(v for v in D.values() if v<0)},'mutants_rejected':['absolute-value source coefficients','synthetic nonstrict lower endpoint','synthetic strict upper endpoint','extra coprimality on common gcd witness'],'scope':'Exact finite zero-large-prime source identity and Gram algebra; no verification of asymptotic estimates, imported theorem, or October 27 role gates.'}
print(json.dumps(result,indent=2))
Path(__file__).with_name('verification_results_'+str(U)+'.json').write_text(json.dumps(result,indent=2)+'\n')
