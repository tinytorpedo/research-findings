#!/usr/bin/env python3
"""Audit transcribed arithmetic only. Not a codec or historical hash verifier."""
import json, pathlib, sys
D=json.loads((pathlib.Path(__file__).parent/'reported_measurements.json').read_text())
checks=[]
def eq(name,actual,expected):
 checks.append({'check':name,'actual':actual,'expected':expected,'pass':actual==expected})
x=D['I12']; eq('I12 saving',x['C8']-x['C9'],x['saving']);eq('I12 accounting',sum(x['accounting']),x['C9'])
x=D['I13'];eq('I13 files',sum(x['files']),60);eq('I13 source',sum(x['source']),21995312);eq('I13 fallback',x['C8'],x['C9']);eq('I13 archives total',sum(x['C9']),5624449);eq('I13 Brotli',sum(x['Brotli']),6233936)
x=D['I14'];eq('I14 C8',sum(x['C8']),297774);eq('I14 C9',sum(x['C9']),249911);eq('I14 saving',sum(x['C8'])-sum(x['C9']),x['saving']);eq('I14 accounting',[sum(a) for a in x['accounting']],x['C9']);eq('I14 source',sum(x['source']),1671641);eq('I14 Brotli',sum(x['Brotli']),382002)
x=D['I16_I17'];tot=[sum(r[i] for r in x['evaluation'].values()) for i in range(6)];eq('I16 I17 evaluation excludes J01',tot,x['totals']);eq('I16 rows',sum(x['evaluation_rows']),6741)
for k,i in [('ellipse',1),('linear',4),('quadratic',5)]:eq('J02 '+k+' accounting',sum(x['J02_accounting'][k]),x['evaluation']['J02'][i])
eq('J02 quadratic overhead net',(1744-424)+(157-156)-(36277-35836),149517-148637)
x=D['I18'];eq('I18 source size',x['samples']*x['bytes_per_sample']+x['wrapper'],x['source']);eq('I18 accounting',sum(x['ellipse_accounting']),x['E']);eq('I18 block headers',x['blocks']*x['header_per_block'],x['ellipse_accounting'][2]);
for k,expected in [('D',-80894),('G',8331),('FLAC',648564),('WavPack',708899)]:eq('I18 ellipse minus '+k,x['E']-x[k],expected)
x=D['I19'];eq('I19 marginal saving',x['baseline']-x['candidate'],2)
percent={}
for key,b,c in [('I12',D['I12']['C8'],D['I12']['C9']),('I14',sum(D['I14']['C8']),sum(D['I14']['C9'])),('I16',tot[0],tot[1]),('I18 versus fixed',D['I18']['D'],D['I18']['E'])]:percent[key]=100*(b-c)/b
out={'scope':'Fresh arithmetic audit of transcribed reported measurements only; no archive decode or historical hash check.','pass':all(c['pass'] for c in checks),'checks':checks,'savings_percent':percent}
print(json.dumps(out,indent=2));sys.exit(0 if out['pass'] else 1)
