PHASE PAIR AND ELLIPSE COMPRESSION REPRODUCIBILITY PACKET

Scope
This packet accompanies the six-page manuscript. It is an arithmetic and provenance packet, not a runnable codec release. Archive sizes and earlier verification outcomes are reported historical evidence. A fresh replay completed 37 decoding checks on copied archives; see FRESH_REPLAY.txt for its limited scope. The included Python audit independently recalculates arithmetic, accounting, and consistency; it does not establish codec correctness or original-file integrity.

Contents
reported_measurements.json: transcribed complete-byte results and accounting.
reported_identities.json: selected historical source, archive and decoder hashes.
audit_measurements.py: Python 3 standard-library audit; no network or dependencies.
audit_results.json: actual output from the included audit.
REPLICATION_PROTOCOL.txt: missing inputs, isolation procedure, pass/fail gates.
REVIEW.txt: falsification-first scope review and known limitations.
FRESH_REPLAY.txt: new retained-artifact decode results and receipt identities.
SHA256SUMS.txt: integrity of this packet's files, not historical objects.

Run
python3 audit_measurements.py
The program reads its adjacent measurements file, performs explicit checks, prints JSON, and exits nonzero on failure. It does not rewrite source records. To retain new output: python3 audit_measurements.py > new_audit_results.json

Data and rights
No private simulation data, audio, original benchmark archives, third-party source code, or dataset payloads are redistributed. Dataset availability is not permission to redistribute. The pinned pendulum revision is b9bfc53d02f7616b2fd8c44d51ba72233d0672b9 at https://huggingface.co/datasets/HumanCompatibleAI/ppo-Pendulum-v1 . Confirm rights and dependencies before a public executable release. This packet does not grant rights in underlying datasets or implementations.

Interpretation
No invented missing values; no silent exclusions; no claim of fresh corpus encoding or full independent replication. I12 development, I13 neutral control, I14 external simulated transfer, I16 operator-informed response tables, I17 retrospective fixed-family comparison, and I18 distinct audio adaptation must remain separate. I19's two-byte result is marginal; I20 is unexecuted.
